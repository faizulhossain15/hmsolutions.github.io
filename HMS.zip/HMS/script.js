function login() {
  var userType = document.getElementById('userType').value;
  var username = document.getElementById('username').value;
  var password = document.getElementById('password').value;
  var loginError = document.getElementById('loginError');

  // Placeholder logic for authentication (replace with actual authentication)
  var authenticated = authenticate(userType, username, password);

  if (authenticated) {
    // Redirect user based on userType
    switch (userType) {
      case 'admin':
        window.location.href = 'admin-dashboard.html';
        break;
      case 'doctor':
        window.location.href = 'doctor-dashboard.html';
        break;
      case 'patient':
        window.location.href = 'patient-dashboard.html';
        break;
      default:
        break;
    }
  } else {
    loginError.textContent = 'Invalid credentials. Please try again.';
  }
}

function authenticate(userType, username, password) {
  // Placeholder logic for authentication (replace with actual authentication)
  // You would typically send a request to your backend to check the credentials
  // and receive a response indicating whether the login is successful.

  // For simplicity, this function returns true for any input.
  return true;
}

document.addEventListener('DOMContentLoaded', function () {
  // Get modal elements
  var addPatientModal = document.getElementById('addPatientModal');
  var addDoctorModal = document.getElementById('addDoctorModal');
  var addAppointmentModal = document.getElementById('addAppointmentModal');

  // Get buttons that open modals
  var openAddPatientModalBtn = document.getElementById('openAddPatientModalBtn');
  var openAddDoctorModalBtn = document.getElementById('openAddDoctorModalBtn');
  var openAddAppointmentModalBtn = document.getElementById('openAddAppointmentModalBtn');

  // Get the close buttons for modals
  var closeAddPatientModalBtn = document.getElementById('closeAddPatientModalBtn');
  var closeAddDoctorModalBtn = document.getElementById('closeAddDoctorModalBtn');
  var closeAddAppointmentModalBtn = document.getElementById('closeAddAppointmentModalBtn');

  // Show modals
  function showModal(modal) {
    modal.style.display = 'block';
  }

  // Hide modals
  function hideModal(modal) {
    modal.style.display = 'none';
  }

  // Event listeners for opening modals
  openAddPatientModalBtn.addEventListener('click', function () {
    showModal(addPatientModal);
  });

  openAddDoctorModalBtn.addEventListener('click', function () {
    showModal(addDoctorModal);
  });

  openAddAppointmentModalBtn.addEventListener('click', function () {
    showModal(addAppointmentModal);
  });

  // Event listeners for closing modals
  closeAddPatientModalBtn.addEventListener('click', function () {
    hideModal(addPatientModal);
  });

  closeAddDoctorModalBtn.addEventListener('click', function () {
    hideModal(addDoctorModal);
  });

  closeAddAppointmentModalBtn.addEventListener('click', function () {
    hideModal(addAppointmentModal);
  });

  // Form submission handling (You can replace this with your own logic)
  var patientForm = document.getElementById('patientForm');
  var doctorForm = document.getElementById('doctorForm');
  var appointmentForm = document.getElementById('appointmentForm');

  patientForm.addEventListener('submit', function (event) {
    event.preventDefault();
    // Add your logic to handle patient form submission here
    hideModal(addPatientModal);
  });

  doctorForm.addEventListener('submit', function (event) {
    event.preventDefault();
    // Add your logic to handle doctor form submission here
    hideModal(addDoctorModal);
  });

  appointmentForm.addEventListener('submit', function (event) {
    event.preventDefault();
    // Add your logic to handle appointment form submission here
    hideModal(addAppointmentModal);
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to display success or error messages
  function showMessage(message, isSuccess) {
    var alertClass = isSuccess ? 'alert-success' : 'alert-error';
    var alertContainer = document.getElementById('alertContainer');
    var alertElement = document.createElement('div');
    alertElement.className = 'alert ' + alertClass;
    alertElement.textContent = message;
    alertContainer.innerHTML = ''; // Clear previous messages
    alertContainer.appendChild(alertElement);
  }

  // Function for basic client-side form validation
  function validateForm(form) {
    var inputs = form.getElementsByTagName('input');
    for (var i = 0; i < inputs.length; i++) {
      var input = inputs[i];
      if (input.hasAttribute('required') && input.value.trim() === '') {
        showMessage('Please fill in all required fields.', false);
        return false;
      }
    }
    return true;
  }

  // Event listeners for form submissions
  patientForm.addEventListener('submit', function (event) {
    event.preventDefault();
    if (validateForm(patientForm)) {
      // Add your logic to handle patient form submission here
      showMessage('Patient added successfully!', true);
      hideModal(addPatientModal);
    }
  });

  doctorForm.addEventListener('submit', function (event) {
    event.preventDefault();
    if (validateForm(doctorForm)) {
      // Add your logic to handle doctor form submission here
      showMessage('Doctor added successfully!', true);
      hideModal(addDoctorModal);
    }
  });

  appointmentForm.addEventListener('submit', function (event) {
    event.preventDefault();
    if (validateForm(appointmentForm)) {
      // Add your logic to handle appointment form submission here
      showMessage('Appointment scheduled successfully!', true);
      hideModal(addAppointmentModal);
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Simulated data for patients, doctors, and appointments
  var patients = [];
  var doctors = [];
  var appointments = [];

  // Function to update patient list
  function updatePatientList() {
    var patientListContainer = document.getElementById('patientList');
    patientListContainer.innerHTML = ''; // Clear previous content
    patients.forEach(function (patient) {
      var listItem = document.createElement('li');
      listItem.textContent = 'Patient ID: ' + patient.id + ', Name: ' + patient.name;
      patientListContainer.appendChild(listItem);
    });
  }

  // Function to update doctor list
  function updateDoctorList() {
    var doctorListContainer = document.getElementById('doctorList');
    doctorListContainer.innerHTML = ''; // Clear previous content
    doctors.forEach(function (doctor) {
      var listItem = document.createElement('li');
      listItem.textContent = 'Doctor ID: ' + doctor.id + ', Name: ' + doctor.name;
      doctorListContainer.appendChild(listItem);
    });
  }

  // Function to update appointment list
  function updateAppointmentList() {
    var appointmentListContainer = document.getElementById('appointmentList');
    appointmentListContainer.innerHTML = ''; // Clear previous content
    appointments.forEach(function (appointment) {
      var listItem = document.createElement('li');
      listItem.textContent =
        'Appointment ID: ' +
        appointment.id +
        ', Patient: ' +
        appointment.patient +
        ', Doctor: ' +
        appointment.doctor +
        ', Date: ' +
        appointment.date;
      appointmentListContainer.appendChild(listItem);
    });
  }

  // Simulated initial data loading (replace with actual server requests)
  patients = [
    { id: 1, name: 'John Doe' },
    { id: 2, name: 'Jane Smith' },
    // Add more patient data as needed
  ];

  doctors = [
    { id: 1, name: 'Dr. Smith' },
    { id: 2, name: 'Dr. Johnson' },
    // Add more doctor data as needed
  ];

  appointments = [
    { id: 1, patient: 'John Doe', doctor: 'Dr. Smith', date: '2023-11-17' },
    { id: 2, patient: 'Jane Smith', doctor: 'Dr. Johnson', date: '2023-11-18' },
    // Add more appointment data as needed
  ];

  // Initial data updates
  updatePatientList();
  updateDoctorList();
  updateAppointmentList();

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to delete a patient by ID
  function deletePatient(patientId) {
    patients = patients.filter(function (patient) {
      return patient.id !== patientId;
    });
    updatePatientList();
  }

  // Function to delete a doctor by ID
  function deleteDoctor(doctorId) {
    doctors = doctors.filter(function (doctor) {
      return doctor.id !== doctorId;
    });
    updateDoctorList();
  }

  // Function to delete an appointment by ID
  function deleteAppointment(appointmentId) {
    appointments = appointments.filter(function (appointment) {
      return appointment.id !== appointmentId;
    });
    updateAppointmentList();
  }

  // Event listener for patient delete button
  document.getElementById('deletePatientBtn').addEventListener('click', function () {
    var patientIdToDelete = parseInt(prompt('Enter the ID of the patient to delete:'));
    if (!isNaN(patientIdToDelete)) {
      deletePatient(patientIdToDelete);
    } else {
      alert('Invalid input. Please enter a valid patient ID.');
    }
  });

  // Event listener for doctor delete button
  document.getElementById('deleteDoctorBtn').addEventListener('click', function () {
    var doctorIdToDelete = parseInt(prompt('Enter the ID of the doctor to delete:'));
    if (!isNaN(doctorIdToDelete)) {
      deleteDoctor(doctorIdToDelete);
    } else {
      alert('Invalid input. Please enter a valid doctor ID.');
    }
  });

  // Event listener for appointment delete button
  document.getElementById('deleteAppointmentBtn').addEventListener('click', function () {
    var appointmentIdToDelete = parseInt(prompt('Enter the ID of the appointment to delete:'));
    if (!isNaN(appointmentIdToDelete)) {
      deleteAppointment(appointmentIdToDelete);
    } else {
      alert('Invalid input. Please enter a valid appointment ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to edit a patient by ID
  function editPatient(patientId, newName) {
    patients = patients.map(function (patient) {
      if (patient.id === patientId) {
        return { ...patient, name: newName };
      }
      return patient;
    });
    updatePatientList();
  }

  // Function to edit a doctor by ID
  function editDoctor(doctorId, newName) {
    doctors = doctors.map(function (doctor) {
      if (doctor.id === doctorId) {
        return { ...doctor, name: newName };
      }
      return doctor;
    });
    updateDoctorList();
  }

  // Function to edit an appointment by ID
  function editAppointment(appointmentId, newPatient, newDoctor, newDate) {
    appointments = appointments.map(function (appointment) {
      if (appointment.id === appointmentId) {
        return { ...appointment, patient: newPatient, doctor: newDoctor, date: newDate };
      }
      return appointment;
    });
    updateAppointmentList();
  }

  // Event listener for patient edit button
  document.getElementById('editPatientBtn').addEventListener('click', function () {
    var patientIdToEdit = parseInt(prompt('Enter the ID of the patient to edit:'));
    var newName = prompt('Enter the new name for the patient:');
    if (!isNaN(patientIdToEdit) && newName !== null) {
      editPatient(patientIdToEdit, newName);
    } else {
      alert('Invalid input. Please enter a valid patient ID and a new name.');
    }
  });

  // Event listener for doctor edit button
  document.getElementById('editDoctorBtn').addEventListener('click', function () {
    var doctorIdToEdit = parseInt(prompt('Enter the ID of the doctor to edit:'));
    var newName = prompt('Enter the new name for the doctor:');
    if (!isNaN(doctorIdToEdit) && newName !== null) {
      editDoctor(doctorIdToEdit, newName);
    } else {
      alert('Invalid input. Please enter a valid doctor ID and a new name.');
    }
  });

  // Event listener for appointment edit button
  document.getElementById('editAppointmentBtn').addEventListener('click', function () {
    var appointmentIdToEdit = parseInt(prompt('Enter the ID of the appointment to edit:'));
    var newPatient = prompt('Enter the new patient name:');
    var newDoctor = prompt('Enter the new doctor name:');
    var newDate = prompt('Enter the new appointment date (YYYY-MM-DD):');
    if (!isNaN(appointmentIdToEdit) && newPatient !== null && newDoctor !== null && newDate !== null) {
      editAppointment(appointmentIdToEdit, newPatient, newDoctor, newDate);
    } else {
      alert('Invalid input. Please enter a valid appointment ID, patient name, doctor name, and date.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to display success messages for edits
  function showEditSuccessMessage(itemType) {
    showMessage(itemType + ' edited successfully!', true);
  }

  // Function to handle editing a patient by ID
  function editPatient(patientId, newName) {
    patients = patients.map(function (patient) {
      if (patient.id === patientId) {
        return { ...patient, name: newName };
      }
      return patient;
    });
    updatePatientList();
    showEditSuccessMessage('Patient');
  }

  // Function to handle editing a doctor by ID
  function editDoctor(doctorId, newName) {
    doctors = doctors.map(function (doctor) {
      if (doctor.id === doctorId) {
        return { ...doctor, name: newName };
      }
      return doctor;
    });
    updateDoctorList();
    showEditSuccessMessage('Doctor');
  }

  // Function to handle editing an appointment by ID
  function editAppointment(appointmentId, newPatient, newDoctor, newDate) {
    appointments = appointments.map(function (appointment) {
      if (appointment.id === appointmentId) {
        return { ...appointment, patient: newPatient, doctor: newDoctor, date: newDate };
      }
      return appointment;
    });
    updateAppointmentList();
    showEditSuccessMessage('Appointment');
  }

  // ... (Previous code remains unchanged)

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to display success messages for deletions
  function showDeleteSuccessMessage(itemType) {
    showMessage(itemType + ' deleted successfully!', true);
  }

  // Function to handle deleting a patient by ID
  function deletePatient(patientId) {
    patients = patients.filter(function (patient) {
      return patient.id !== patientId;
    });
    updatePatientList();
    showDeleteSuccessMessage('Patient');
  }

  // Function to handle deleting a doctor by ID
  function deleteDoctor(doctorId) {
    doctors = doctors.filter(function (doctor) {
      return doctor.id !== doctorId;
    });
    updateDoctorList();
    showDeleteSuccessMessage('Doctor');
  }

  // Function to handle deleting an appointment by ID
  function deleteAppointment(appointmentId) {
    appointments = appointments.filter(function (appointment) {
      return appointment.id !== appointmentId;
    });
    updateAppointmentList();
    showDeleteSuccessMessage('Appointment');
  }

  // Event listener for patient delete button
  document.getElementById('deletePatientBtn').addEventListener('click', function () {
    var patientIdToDelete = parseInt(prompt('Enter the ID of the patient to delete:'));
    if (!isNaN(patientIdToDelete)) {
      deletePatient(patientIdToDelete);
    } else {
      alert('Invalid input. Please enter a valid patient ID.');
    }
  });

  // Event listener for doctor delete button
  document.getElementById('deleteDoctorBtn').addEventListener('click', function () {
    var doctorIdToDelete = parseInt(prompt('Enter the ID of the doctor to delete:'));
    if (!isNaN(doctorIdToDelete)) {
      deleteDoctor(doctorIdToDelete);
    } else {
      alert('Invalid input. Please enter a valid doctor ID.');
    }
  });

  // Event listener for appointment delete button
  document.getElementById('deleteAppointmentBtn').addEventListener('click', function () {
    var appointmentIdToDelete = parseInt(prompt('Enter the ID of the appointment to delete:'));
    if (!isNaN(appointmentIdToDelete)) {
      deleteAppointment(appointmentIdToDelete);
    } else {
      alert('Invalid input. Please enter a valid appointment ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to filter patients based on user input
  function filterPatients(query) {
    var filteredPatients = patients.filter(function (patient) {
      return patient.name.toLowerCase().includes(query.toLowerCase());
    });
    updatePatientList(filteredPatients);
  }

  // Function to filter doctors based on user input
  function filterDoctors(query) {
    var filteredDoctors = doctors.filter(function (doctor) {
      return doctor.name.toLowerCase().includes(query.toLowerCase());
    });
    updateDoctorList(filteredDoctors);
  }

  // Function to filter appointments based on user input
  function filterAppointments(query) {
    var filteredAppointments = appointments.filter(function (appointment) {
      return (
        appointment.patient.toLowerCase().includes(query.toLowerCase()) ||
        appointment.doctor.toLowerCase().includes(query.toLowerCase())
      );
    });
    updateAppointmentList(filteredAppointments);
  }

  // Event listener for patient search input
  document.getElementById('searchPatientInput').addEventListener('input', function (event) {
    var searchQuery = event.target.value.trim();
    filterPatients(searchQuery);
  });

  // Event listener for doctor search input
  document.getElementById('searchDoctorInput').addEventListener('input', function (event) {
    var searchQuery = event.target.value.trim();
    filterDoctors(searchQuery);
  });

  // Event listener for appointment search input
  document.getElementById('searchAppointmentInput').addEventListener('input', function (event) {
    var searchQuery = event.target.value.trim();
    filterAppointments(searchQuery);
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to sort patients by name
  function sortPatientsByName() {
    patients.sort(function (a, b) {
      return a.name.localeCompare(b.name);
    });
    updatePatientList();
  }

  // Function to sort doctors by name
  function sortDoctorsByName() {
    doctors.sort(function (a, b) {
      return a.name.localeCompare(b.name);
    });
    updateDoctorList();
  }

  // Function to sort appointments by date
  function sortAppointmentsByDate() {
    appointments.sort(function (a, b) {
      return new Date(a.date) - new Date(b.date);
    });
    updateAppointmentList();
  }

  // Event listener for patient sort button
  document.getElementById('sortPatientsBtn').addEventListener('click', function () {
    sortPatientsByName();
  });

  // Event listener for doctor sort button
  document.getElementById('sortDoctorsBtn').addEventListener('click', function () {
    sortDoctorsByName();
  });

  // Event listener for appointment sort button
  document.getElementById('sortAppointmentsBtn').addEventListener('click', function () {
    sortAppointmentsByDate();
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Constants for pagination
  const itemsPerPage = 5;
  let currentPagePatients = 1;
  let currentPageDoctors = 1;
  let currentPageAppointments = 1;

  // Function to display a specific page of patients
  function displayPatientsPage(page) {
    var startIndex = (page - 1) * itemsPerPage;
    var endIndex = startIndex + itemsPerPage;
    var patientsPage = patients.slice(startIndex, endIndex);
    updatePatientList(patientsPage);
  }

  // Function to display a specific page of doctors
  function displayDoctorsPage(page) {
    var startIndex = (page - 1) * itemsPerPage;
    var endIndex = startIndex + itemsPerPage;
    var doctorsPage = doctors.slice(startIndex, endIndex);
    updateDoctorList(doctorsPage);
  }

  // Function to display a specific page of appointments
  function displayAppointmentsPage(page) {
    var startIndex = (page - 1) * itemsPerPage;
    var endIndex = startIndex + itemsPerPage;
    var appointmentsPage = appointments.slice(startIndex, endIndex);
    updateAppointmentList(appointmentsPage);
  }

  // Function to update the pagination buttons
  function updatePaginationButtons(totalPages, currentPage, elementId) {
    var paginationContainer = document.getElementById(elementId);
    paginationContainer.innerHTML = '';

    for (var i = 1; i <= totalPages; i++) {
      var button = document.createElement('button');
      button.textContent = i;
      button.addEventListener('click', function (event) {
        var pageNumber = parseInt(event.target.textContent);
        if (!isNaN(pageNumber)) {
          switch (elementId) {
            case 'patientPagination':
              displayPatientsPage(pageNumber);
              break;
            case 'doctorPagination':
              displayDoctorsPage(pageNumber);
              break;
            case 'appointmentPagination':
              displayAppointmentsPage(pageNumber);
              break;
          }
        }
      });

      if (i === currentPage) {
        button.classList.add('active');
      }

      paginationContainer.appendChild(button);
    }
  }

  // Event listener for patient pagination
  document.getElementById('patientPagination').addEventListener('DOMContentLoaded', function () {
    displayPatientsPage(currentPagePatients);
  });

  // Event listener for doctor pagination
  document.getElementById('doctorPagination').addEventListener('DOMContentLoaded', function () {
    displayDoctorsPage(currentPageDoctors);
  });

  // Event listener for appointment pagination
  document.getElementById('appointmentPagination').addEventListener('DOMContentLoaded', function () {
    displayAppointmentsPage(currentPageAppointments);
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to display details of a specific patient
  function viewPatientDetails(patientId) {
    var patient = patients.find(function (patient) {
      return patient.id === patientId;
    });

    if (patient) {
      alert('Patient Details:\n\nID: ' + patient.id + '\nName: ' + patient.name);
    } else {
      alert('Patient not found.');
    }
  }

  // Function to display details of a specific doctor
  function viewDoctorDetails(doctorId) {
    var doctor = doctors.find(function (doctor) {
      return doctor.id === doctorId;
    });

    if (doctor) {
      alert('Doctor Details:\n\nID: ' + doctor.id + '\nName: ' + doctor.name);
    } else {
      alert('Doctor not found.');
    }
  }

  // Function to display details of a specific appointment
  function viewAppointmentDetails(appointmentId) {
    var appointment = appointments.find(function (appointment) {
      return appointment.id === appointmentId;
    });

    if (appointment) {
      alert(
        'Appointment Details:\n\nID: ' +
          appointment.id +
          '\nPatient: ' +
          appointment.patient +
          '\nDoctor: ' +
          appointment.doctor +
          '\nDate: ' +
          appointment.date
      );
    } else {
      alert('Appointment not found.');
    }
  }

  // Event listener for patient details button
  document.getElementById('viewPatientDetailsBtn').addEventListener('click', function () {
    var patientIdToView = parseInt(prompt('Enter the ID of the patient to view details:'));
    if (!isNaN(patientIdToView)) {
      viewPatientDetails(patientIdToView);
    } else {
      alert('Invalid input. Please enter a valid patient ID.');
    }
  });

  // Event listener for doctor details button
  document.getElementById('viewDoctorDetailsBtn').addEventListener('click', function () {
    var doctorIdToView = parseInt(prompt('Enter the ID of the doctor to view details:'));
    if (!isNaN(doctorIdToView)) {
      viewDoctorDetails(doctorIdToView);
    } else {
      alert('Invalid input. Please enter a valid doctor ID.');
    }
  });

  // Event listener for appointment details button
  document.getElementById('viewAppointmentDetailsBtn').addEventListener('click', function () {
    var appointmentIdToView = parseInt(prompt('Enter the ID of the appointment to view details:'));
    if (!isNaN(appointmentIdToView)) {
      viewAppointmentDetails(appointmentIdToView);
    } else {
      alert('Invalid input. Please enter a valid appointment ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to edit details of a specific patient
  function editPatientDetails(patientId, newName) {
    var patientIndex = patients.findIndex(function (patient) {
      return patient.id === patientId;
    });

    if (patientIndex !== -1) {
      patients[patientIndex].name = newName;
      updatePatientList();
      alert('Patient details edited successfully!');
    } else {
      alert('Patient not found.');
    }
  }

  // Function to edit details of a specific doctor
  function editDoctorDetails(doctorId, newName) {
    var doctorIndex = doctors.findIndex(function (doctor) {
      return doctor.id === doctorId;
    });

    if (doctorIndex !== -1) {
      doctors[doctorIndex].name = newName;
      updateDoctorList();
      alert('Doctor details edited successfully!');
    } else {
      alert('Doctor not found.');
    }
  }

  // Function to edit details of a specific appointment
  function editAppointmentDetails(appointmentId, newPatient, newDoctor, newDate) {
    var appointmentIndex = appointments.findIndex(function (appointment) {
      return appointment.id === appointmentId;
    });

    if (appointmentIndex !== -1) {
      appointments[appointmentIndex].patient = newPatient;
      appointments[appointmentIndex].doctor = newDoctor;
      appointments[appointmentIndex].date = newDate;
      updateAppointmentList();
      alert('Appointment details edited successfully!');
    } else {
      alert('Appointment not found.');
    }
  }

  // Event listener for patient edit details button
  document.getElementById('editPatientDetailsBtn').addEventListener('click', function () {
    var patientIdToEdit = parseInt(prompt('Enter the ID of the patient to edit details:'));
    var newName = prompt('Enter the new name for the patient:');
    if (!isNaN(patientIdToEdit) && newName !== null) {
      editPatientDetails(patientIdToEdit, newName);
    } else {
      alert('Invalid input. Please enter a valid patient ID and a new name.');
    }
  });

  // Event listener for doctor edit details button
  document.getElementById('editDoctorDetailsBtn').addEventListener('click', function () {
    var doctorIdToEdit = parseInt(prompt('Enter the ID of the doctor to edit details:'));
    var newName = prompt('Enter the new name for the doctor:');
    if (!isNaN(doctorIdToEdit) && newName !== null) {
      editDoctorDetails(doctorIdToEdit, newName);
    } else {
      alert('Invalid input. Please enter a valid doctor ID and a new name.');
    }
  });

  // Event listener for appointment edit details button
  document.getElementById('editAppointmentDetailsBtn').addEventListener('click', function () {
    var appointmentIdToEdit = parseInt(prompt('Enter the ID of the appointment to edit details:'));
    var newPatient = prompt('Enter the new patient name:');
    var newDoctor = prompt('Enter the new doctor name:');
    var newDate = prompt('Enter the new appointment date (YYYY-MM-DD):');
    if (!isNaN(appointmentIdToEdit) && newPatient !== null && newDoctor !== null && newDate !== null) {
      editAppointmentDetails(appointmentIdToEdit, newPatient, newDoctor, newDate);
    } else {
      alert('Invalid input. Please enter a valid appointment ID, patient name, doctor name, and date.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to add a new patient
  function addNewPatient(newPatientName) {
    var newPatientId = patients.length + 1;
    var newPatient = { id: newPatientId, name: newPatientName };
    patients.push(newPatient);
    updatePatientList();
    alert('New patient added successfully!');
  }

  // Function to add a new doctor
  function addNewDoctor(newDoctorName) {
    var newDoctorId = doctors.length + 1;
    var newDoctor = { id: newDoctorId, name: newDoctorName };
    doctors.push(newDoctor);
    updateDoctorList();
    alert('New doctor added successfully!');
  }

  // Function to add a new appointment
  function addNewAppointment(newPatient, newDoctor, newDate) {
    var newAppointmentId = appointments.length + 1;
    var newAppointment = { id: newAppointmentId, patient: newPatient, doctor: newDoctor, date: newDate };
    appointments.push(newAppointment);
    updateAppointmentList();
    alert('New appointment added successfully!');
  }

  // Event listener for add new patient button
  document.getElementById('addNewPatientBtn').addEventListener('click', function () {
    var newPatientName = prompt('Enter the name of the new patient:');
    if (newPatientName !== null) {
      addNewPatient(newPatientName);
    } else {
      alert('Invalid input. Please enter a valid name for the new patient.');
    }
  });

  // Event listener for add new doctor button
  document.getElementById('addNewDoctorBtn').addEventListener('click', function () {
    var newDoctorName = prompt('Enter the name of the new doctor:');
    if (newDoctorName !== null) {
      addNewDoctor(newDoctorName);
    } else {
      alert('Invalid input. Please enter a valid name for the new doctor.');
    }
  });

  // Event listener for add new appointment button
  document.getElementById('addNewAppointmentBtn').addEventListener('click', function () {
    var newPatient = prompt('Enter the name of the new patient for the appointment:');
    var newDoctor = prompt('Enter the name of the new doctor for the appointment:');
    var newDate = prompt('Enter the date of the new appointment (YYYY-MM-DD):');
    if (newPatient !== null && newDoctor !== null && newDate !== null) {
      addNewAppointment(newPatient, newDoctor, newDate);
    } else {
      alert('Invalid input. Please enter valid details for the new appointment.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to add a new patient with input validation
  function addNewPatient(newPatientName) {
    if (newPatientName.trim() !== '') {
      var newPatientId = patients.length + 1;
      var newPatient = { id: newPatientId, name: newPatientName };
      patients.push(newPatient);
      updatePatientList();
      alert('New patient added successfully!');
    } else {
      alert('Invalid input. Please enter a valid name for the new patient.');
    }
  }

  // Function to add a new doctor with input validation
  function addNewDoctor(newDoctorName) {
    if (newDoctorName.trim() !== '') {
      var newDoctorId = doctors.length + 1;
      var newDoctor = { id: newDoctorId, name: newDoctorName };
      doctors.push(newDoctor);
      updateDoctorList();
      alert('New doctor added successfully!');
    } else {
      alert('Invalid input. Please enter a valid name for the new doctor.');
    }
  }

  // Function to add a new appointment with input validation
  function addNewAppointment(newPatient, newDoctor, newDate) {
    if (newPatient.trim() !== '' && newDoctor.trim() !== '' && isValidDate(newDate)) {
      var newAppointmentId = appointments.length + 1;
      var newAppointment = { id: newAppointmentId, patient: newPatient, doctor: newDoctor, date: newDate };
      appointments.push(newAppointment);
      updateAppointmentList();
      alert('New appointment added successfully!');
    } else {
      alert('Invalid input. Please enter valid details for the new appointment.');
    }
  }

  // Function to validate a date string (YYYY-MM-DD)
  function isValidDate(dateString) {
    var regex = /^\d{4}-\d{2}-\d{2}$/;
    return regex.test(dateString);
  }

  // Event listener for add new patient button
  document.getElementById('addNewPatientBtn').addEventListener('click', function () {
    var newPatientName = prompt('Enter the name of the new patient:');
    if (newPatientName !== null) {
      addNewPatient(newPatientName);
    }
  });

  // Event listener for add new doctor button
  document.getElementById('addNewDoctorBtn').addEventListener('click', function () {
    var newDoctorName = prompt('Enter the name of the new doctor:');
    if (newDoctorName !== null) {
      addNewDoctor(newDoctorName);
    }
  });

  // Event listener for add new appointment button
  document.getElementById('addNewAppointmentBtn').addEventListener('click', function () {
    var newPatient = prompt('Enter the name of the new patient for the appointment:');
    var newDoctor = prompt('Enter the name of the new doctor for the appointment:');
    var newDate = prompt('Enter the date of the new appointment (YYYY-MM-DD):');
    if (newPatient !== null && newDoctor !== null && newDate !== null) {
      addNewAppointment(newPatient, newDoctor, newDate);
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to filter appointments based on date range
  function filterAppointmentsByDateRange(startDate, endDate) {
    var filteredAppointments = appointments.filter(function (appointment) {
      var appointmentDate = new Date(appointment.date);
      return appointmentDate >= startDate && appointmentDate <= endDate;
    });
    updateAppointmentList(filteredAppointments);
  }

  // Event listener for date range filter button
  document.getElementById('filterAppointmentsBtn').addEventListener('click', function () {
    var startDateString = prompt('Enter the start date for filtering (YYYY-MM-DD):');
    var endDateString = prompt('Enter the end date for filtering (YYYY-MM-DD):');

    if (isValidDate(startDateString) && isValidDate(endDateString)) {
      var startDate = new Date(startDateString);
      var endDate = new Date(endDateString);
      filterAppointmentsByDateRange(startDate, endDate);
    } else {
      alert('Invalid date input. Please enter valid start and end dates.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to delete a patient
  function deletePatient(patientId) {
    var patientIndex = patients.findIndex(function (patient) {
      return patient.id === patientId;
    });

    if (patientIndex !== -1) {
      patients.splice(patientIndex, 1);
      updatePatientList();
      alert('Patient deleted successfully!');
    } else {
      alert('Patient not found.');
    }
  }

  // Function to delete a doctor
  function deleteDoctor(doctorId) {
    var doctorIndex = doctors.findIndex(function (doctor) {
      return doctor.id === doctorId;
    });

    if (doctorIndex !== -1) {
      doctors.splice(doctorIndex, 1);
      updateDoctorList();
      alert('Doctor deleted successfully!');
    } else {
      alert('Doctor not found.');
    }
  }

  // Function to delete an appointment
  function deleteAppointment(appointmentId) {
    var appointmentIndex = appointments.findIndex(function (appointment) {
      return appointment.id === appointmentId;
    });

    if (appointmentIndex !== -1) {
      appointments.splice(appointmentIndex, 1);
      updateAppointmentList();
      alert('Appointment deleted successfully!');
    } else {
      alert('Appointment not found.');
    }
  }

  // Event listener for delete patient button
  document.getElementById('deletePatientBtn').addEventListener('click', function () {
    var patientIdToDelete = parseInt(prompt('Enter the ID of the patient to delete:'));
    if (!isNaN(patientIdToDelete)) {
      deletePatient(patientIdToDelete);
    } else {
      alert('Invalid input. Please enter a valid patient ID.');
    }
  });

  // Event listener for delete doctor button
  document.getElementById('deleteDoctorBtn').addEventListener('click', function () {
    var doctorIdToDelete = parseInt(prompt('Enter the ID of the doctor to delete:'));
    if (!isNaN(doctorIdToDelete)) {
      deleteDoctor(doctorIdToDelete);
    } else {
      alert('Invalid input. Please enter a valid doctor ID.');
    }
  });

  // Event listener for delete appointment button
  document.getElementById('deleteAppointmentBtn').addEventListener('click', function () {
    var appointmentIdToDelete = parseInt(prompt('Enter the ID of the appointment to delete:'));
    if (!isNaN(appointmentIdToDelete)) {
      deleteAppointment(appointmentIdToDelete);
    } else {
      alert('Invalid input. Please enter a valid appointment ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to search for patients by name
  function searchPatientsByName(query) {
    var searchResults = patients.filter(function (patient) {
      return patient.name.toLowerCase().includes(query.toLowerCase());
    });
    updatePatientList(searchResults);
  }

  // Function to search for doctors by name
  function searchDoctorsByName(query) {
    var searchResults = doctors.filter(function (doctor) {
      return doctor.name.toLowerCase().includes(query.toLowerCase());
    });
    updateDoctorList(searchResults);
  }

  // Function to search for appointments by patient or doctor name
  function searchAppointmentsByPatientOrDoctor(query) {
    var searchResults = appointments.filter(function (appointment) {
      return (
        appointment.patient.toLowerCase().includes(query.toLowerCase()) ||
        appointment.doctor.toLowerCase().includes(query.toLowerCase())
      );
    });
    updateAppointmentList(searchResults);
  }

  // Event listener for search patients button
  document.getElementById('searchPatientsBtn').addEventListener('click', function () {
    var patientQuery = prompt('Enter the name of the patient to search:');
    if (patientQuery !== null) {
      searchPatientsByName(patientQuery);
    }
  });

  // Event listener for search doctors button
  document.getElementById('searchDoctorsBtn').addEventListener('click', function () {
    var doctorQuery = prompt('Enter the name of the doctor to search:');
    if (doctorQuery !== null) {
      searchDoctorsByName(doctorQuery);
    }
  });

  // Event listener for search appointments button
  document.getElementById('searchAppointmentsBtn').addEventListener('click', function () {
    var appointmentQuery = prompt('Enter the name of the patient or doctor to search in appointments:');
    if (appointmentQuery !== null) {
      searchAppointmentsByPatientOrDoctor(appointmentQuery);
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to sort patients by name
  function sortPatientsByName() {
    patients.sort(function (a, b) {
      return a.name.localeCompare(b.name);
    });
    updatePatientList();
  }

  // Function to sort doctors by name
  function sortDoctorsByName() {
    doctors.sort(function (a, b) {
      return a.name.localeCompare(b.name);
    });
    updateDoctorList();
  }

  // Function to sort appointments by date
  function sortAppointmentsByDate() {
    appointments.sort(function (a, b) {
      var dateA = new Date(a.date);
      var dateB = new Date(b.date);
      return dateA - dateB;
    });
    updateAppointmentList();
  }

  // Event listener for sort patients button
  document.getElementById('sortPatientsBtn').addEventListener('click', function () {
    sortPatientsByName();
  });

  // Event listener for sort doctors button
  document.getElementById('sortDoctorsBtn').addEventListener('click', function () {
    sortDoctorsByName();
  });

  // Event listener for sort appointments button
  document.getElementById('sortAppointmentsBtn').addEventListener('click', function () {
    sortAppointmentsByDate();
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to update patient details
  function updatePatientDetails(patientId, newName) {
    var patient = patients.find(function (patient) {
      return patient.id === patientId;
    });

    if (patient) {
      patient.name = newName;
      updatePatientList();
      alert('Patient details updated successfully!');
    } else {
      alert('Patient not found.');
    }
  }

  // Function to update doctor details
  function updateDoctorDetails(doctorId, newName) {
    var doctor = doctors.find(function (doctor) {
      return doctor.id === doctorId;
    });

    if (doctor) {
      doctor.name = newName;
      updateDoctorList();
      alert('Doctor details updated successfully!');
    } else {
      alert('Doctor not found.');
    }
  }

  // Event listener for update patient details button
  document.getElementById('updatePatientDetailsBtn').addEventListener('click', function () {
    var patientIdToUpdate = parseInt(prompt('Enter the ID of the patient to update details:'));
    var newName = prompt('Enter the new name for the patient:');
    if (!isNaN(patientIdToUpdate) && newName !== null) {
      updatePatientDetails(patientIdToUpdate, newName);
    } else {
      alert('Invalid input. Please enter a valid patient ID and a new name.');
    }
  });

  // Event listener for update doctor details button
  document.getElementById('updateDoctorDetailsBtn').addEventListener('click', function () {
    var doctorIdToUpdate = parseInt(prompt('Enter the ID of the doctor to update details:'));
    var newName = prompt('Enter the new name for the doctor:');
    if (!isNaN(doctorIdToUpdate) && newName !== null) {
      updateDoctorDetails(doctorIdToUpdate, newName);
    } else {
      alert('Invalid input. Please enter a valid doctor ID and a new name.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to update appointment details
  function updateAppointmentDetails(appointmentId, newPatient, newDoctor, newDate) {
    var appointment = appointments.find(function (appointment) {
      return appointment.id === appointmentId;
    });

    if (appointment) {
      appointment.patient = newPatient;
      appointment.doctor = newDoctor;
      appointment.date = newDate;
      updateAppointmentList();
      alert('Appointment details updated successfully!');
    } else {
      alert('Appointment not found.');
    }
  }

  // Event listener for update appointment details button
  document.getElementById('updateAppointmentDetailsBtn').addEventListener('click', function () {
    var appointmentIdToUpdate = parseInt(prompt('Enter the ID of the appointment to update details:'));
    var newPatient = prompt('Enter the new patient name:');
    var newDoctor = prompt('Enter the new doctor name:');
    var newDate = prompt('Enter the new appointment date (YYYY-MM-DD):');
    if (!isNaN(appointmentIdToUpdate) && newPatient !== null && newDoctor !== null && newDate !== null) {
      updateAppointmentDetails(appointmentIdToUpdate, newPatient, newDoctor, newDate);
    } else {
      alert('Invalid input. Please enter a valid appointment ID, patient name, doctor name, and date.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to update appointment details with input validation
  function updateAppointmentDetails(appointmentId, newPatient, newDoctor, newDate) {
    var appointment = appointments.find(function (appointment) {
      return appointment.id === appointmentId;
    });

    if (appointment) {
      if (newPatient.trim() !== '' && newDoctor.trim() !== '' && isValidDate(newDate)) {
        appointment.patient = newPatient;
        appointment.doctor = newDoctor;
        appointment.date = newDate;
        updateAppointmentList();
        alert('Appointment details updated successfully!');
      } else {
        alert('Invalid input. Please enter valid patient name, doctor name, and date.');
      }
    } else {
      alert('Appointment not found.');
    }
  }

  // Event listener for update appointment details button
  document.getElementById('updateAppointmentDetailsBtn').addEventListener('click', function () {
    var appointmentIdToUpdate = parseInt(prompt('Enter the ID of the appointment to update details:'));
    var newPatient = prompt('Enter the new patient name:');
    var newDoctor = prompt('Enter the new doctor name:');
    var newDate = prompt('Enter the new appointment date (YYYY-MM-DD):');
    if (!isNaN(appointmentIdToUpdate)) {
      updateAppointmentDetails(appointmentIdToUpdate, newPatient, newDoctor, newDate);
    } else {
      alert('Invalid input. Please enter a valid appointment ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to display detailed information for a specific patient
  function viewPatientDetails(patientId) {
    var patient = patients.find(function (patient) {
      return patient.id === patientId;
    });

    if (patient) {
      alert('Patient Details:\n\nID: ' + patient.id + '\nName: ' + patient.name);
    } else {
      alert('Patient not found.');
    }
  }

  // Function to display detailed information for a specific doctor
  function viewDoctorDetails(doctorId) {
    var doctor = doctors.find(function (doctor) {
      return doctor.id === doctorId;
    });

    if (doctor) {
      alert('Doctor Details:\n\nID: ' + doctor.id + '\nName: ' + doctor.name);
    } else {
      alert('Doctor not found.');
    }
  }

  // Function to display detailed information for a specific appointment
  function viewAppointmentDetails(appointmentId) {
    var appointment = appointments.find(function (appointment) {
      return appointment.id === appointmentId;
    });

    if (appointment) {
      alert(
        'Appointment Details:\n\nID: ' +
          appointment.id +
          '\nPatient: ' +
          appointment.patient +
          '\nDoctor: ' +
          appointment.doctor +
          '\nDate: ' +
          appointment.date
      );
    } else {
      alert('Appointment not found.');
    }
  }

  // Event listener for view patient details button
  document.getElementById('viewPatientDetailsBtn').addEventListener('click', function () {
    var patientIdToView = parseInt(prompt('Enter the ID of the patient to view details:'));
    if (!isNaN(patientIdToView)) {
      viewPatientDetails(patientIdToView);
    } else {
      alert('Invalid input. Please enter a valid patient ID.');
    }
  });

  // Event listener for view doctor details button
  document.getElementById('viewDoctorDetailsBtn').addEventListener('click', function () {
    var doctorIdToView = parseInt(prompt('Enter the ID of the doctor to view details:'));
    if (!isNaN(doctorIdToView)) {
      viewDoctorDetails(doctorIdToView);
    } else {
      alert('Invalid input. Please enter a valid doctor ID.');
    }
  });

  // Event listener for view appointment details button
  document.getElementById('viewAppointmentDetailsBtn').addEventListener('click', function () {
    var appointmentIdToView = parseInt(prompt('Enter the ID of the appointment to view details:'));
    if (!isNaN(appointmentIdToView)) {
      viewAppointmentDetails(appointmentIdToView);
    } else {
      alert('Invalid input. Please enter a valid appointment ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to show a specific section and hide others
  function showSection(sectionId) {
    var allSections = document.querySelectorAll('.section');
    allSections.forEach(function (section) {
      section.style.display = 'none';
    });

    var selectedSection = document.getElementById(sectionId);
    if (selectedSection) {
      selectedSection.style.display = 'block';
    } else {
      alert('Section not found.');
    }
  }

  // Event listener for navigation buttons
  document.getElementById('patientsSectionBtn').addEventListener('click', function () {
    showSection('patientsSection');
  });

  document.getElementById('doctorsSectionBtn').addEventListener('click', function () {
    showSection('doctorsSection');
  });

  document.getElementById('appointmentsSectionBtn').addEventListener('click', function () {
    showSection('appointmentsSection');
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to generate a report on patient data
  function generatePatientReport() {
    // Customize the report generation logic based on your requirements
    var report = 'Patient Report:\n\n';
    patients.forEach(function (patient) {
      report += 'ID: ' + patient.id + '\tName: ' + patient.name + '\n';
    });

    alert(report);
  }

  // Function to perform analytics on patient data
  function performPatientAnalytics() {
    // Customize the analytics logic based on your requirements
    var totalPatients = patients.length;
    var averageNameLength =
      patients.reduce(function (sum, patient) {
        return sum + patient.name.length;
      }, 0) / totalPatients;

    alert('Patient Analytics:\n\nTotal Patients: ' + totalPatients + '\nAverage Name Length: ' + averageNameLength.toFixed(2));
  }

  // Event listener for generate patient report button
  document.getElementById('generatePatientReportBtn').addEventListener('click', function () {
    generatePatientReport();
  });

  // Event listener for perform patient analytics button
  document.getElementById('performPatientAnalyticsBtn').addEventListener('click', function () {
    performPatientAnalytics();
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to export patient data as CSV
  function exportPatientDataCSV() {
    var csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'ID,Name\n';

    patients.forEach(function (patient) {
      csvContent += patient.id + ',' + patient.name + '\n';
    });

    var encodedUri = encodeURI(csvContent);
    var link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'patient_data.csv');
    document.body.appendChild(link);
    link.click();
  }

  // Function to export patient data as JSON
  function exportPatientDataJSON() {
    var jsonData = JSON.stringify(patients, null, 2);
    var blob = new Blob([jsonData], { type: 'application/json' });
    var link = document.createElement('a');
    link.href = window.URL.createObjectURL(blob);
    link.download = 'patient_data.json';
    document.body.appendChild(link);
    link.click();
  }

  // Event listener for export patient data as CSV button
  document.getElementById('exportPatientDataCSVBtn').addEventListener('click', function () {
    exportPatientDataCSV();
  });

  // Event listener for export patient data as JSON button
  document.getElementById('exportPatientDataJSONBtn').addEventListener('click', function () {
    exportPatientDataJSON();
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to filter appointments based on date range
  function filterAppointmentsByDateRange(startDate, endDate) {
    var filteredAppointments = appointments.filter(function (appointment) {
      var appointmentDate = new Date(appointment.date);
      return appointmentDate >= startDate && appointmentDate <= endDate;
    });

    updateAppointmentList(filteredAppointments);
  }

  // Event listener for filter appointments by date range button
  document.getElementById('filterAppointmentsByDateBtn').addEventListener('click', function () {
    var startDate = prompt('Enter the start date (YYYY-MM-DD):');
    var endDate = prompt('Enter the end date (YYYY-MM-DD):');

    if (isValidDate(startDate) && isValidDate(endDate)) {
      filterAppointmentsByDateRange(new Date(startDate), new Date(endDate));
    } else {
      alert('Invalid input. Please enter valid start and end dates.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to delete a patient by ID
  function deletePatientById(patientId) {
    var index = patients.findIndex(function (patient) {
      return patient.id === patientId;
    });

    if (index !== -1) {
      patients.splice(index, 1);
      updatePatientList();
      alert('Patient deleted successfully!');
    } else {
      alert('Patient not found.');
    }
  }

  // Function to delete a doctor by ID
  function deleteDoctorById(doctorId) {
    var index = doctors.findIndex(function (doctor) {
      return doctor.id === doctorId;
    });

    if (index !== -1) {
      doctors.splice(index, 1);
      updateDoctorList();
      alert('Doctor deleted successfully!');
    } else {
      alert('Doctor not found.');
    }
  }

  // Function to delete an appointment by ID
  function deleteAppointmentById(appointmentId) {
    var index = appointments.findIndex(function (appointment) {
      return appointment.id === appointmentId;
    });

    if (index !== -1) {
      appointments.splice(index, 1);
      updateAppointmentList();
      alert('Appointment deleted successfully!');
    } else {
      alert('Appointment not found.');
    }
  }

  // Event listener for delete patient button
  document.getElementById('deletePatientBtn').addEventListener('click', function () {
    var patientIdToDelete = parseInt(prompt('Enter the ID of the patient to delete:'));
    if (!isNaN(patientIdToDelete)) {
      deletePatientById(patientIdToDelete);
    } else {
      alert('Invalid input. Please enter a valid patient ID.');
    }
  });

  // Event listener for delete doctor button
  document.getElementById('deleteDoctorBtn').addEventListener('click', function () {
    var doctorIdToDelete = parseInt(prompt('Enter the ID of the doctor to delete:'));
    if (!isNaN(doctorIdToDelete)) {
      deleteDoctorById(doctorIdToDelete);
    } else {
      alert('Invalid input. Please enter a valid doctor ID.');
    }
  });

  // Event listener for delete appointment button
  document.getElementById('deleteAppointmentBtn').addEventListener('click', function () {
    var appointmentIdToDelete = parseInt(prompt('Enter the ID of the appointment to delete:'));
    if (!isNaN(appointmentIdToDelete)) {
      deleteAppointmentById(appointmentIdToDelete);
    } else {
      alert('Invalid input. Please enter a valid appointment ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to search for a patient by name
  function searchPatientByName() {
    var searchTerm = prompt('Enter the name of the patient to search:');
    if (searchTerm !== null) {
      var searchResults = patients.filter(function (patient) {
        return patient.name.toLowerCase().includes(searchTerm.toLowerCase());
      });

      if (searchResults.length > 0) {
        updatePatientList(searchResults);
      } else {
        alert('No matching patients found.');
      }
    }
  }

  // Function to search for a doctor by name
  function searchDoctorByName() {
    var searchTerm = prompt('Enter the name of the doctor to search:');
    if (searchTerm !== null) {
      var searchResults = doctors.filter(function (doctor) {
        return doctor.name.toLowerCase().includes(searchTerm.toLowerCase());
      });

      if (searchResults.length > 0) {
        updateDoctorList(searchResults);
      } else {
        alert('No matching doctors found.');
      }
    }
  }

  // Function to search for an appointment by patient name or doctor name
  function searchAppointmentByPatientOrDoctor() {
    var searchTerm = prompt('Enter the name of the patient or doctor to search in appointments:');
    if (searchTerm !== null) {
      var searchResults = appointments.filter(function (appointment) {
        return (
          appointment.patient.toLowerCase().includes(searchTerm.toLowerCase()) ||
          appointment.doctor.toLowerCase().includes(searchTerm.toLowerCase())
        );
      });

      if (searchResults.length > 0) {
        updateAppointmentList(searchResults);
      } else {
        alert('No matching appointments found.');
      }
    }
  }

  // Event listener for search patient button
  document.getElementById('searchPatientBtn').addEventListener('click', function () {
    searchPatientByName();
  });

  // Event listener for search doctor button
  document.getElementById('searchDoctorBtn').addEventListener('click', function () {
    searchDoctorByName();
  });

  // Event listener for search appointment button
  document.getElementById('searchAppointmentBtn').addEventListener('click', function () {
    searchAppointmentByPatientOrDoctor();
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to edit patient details by ID
  function editPatientById(patientId) {
    var index = patients.findIndex(function (patient) {
      return patient.id === patientId;
    });

    if (index !== -1) {
      var newName = prompt('Enter the new name for the patient:');
      if (newName !== null) {
        patients[index].name = newName;
        updatePatientList();
        alert('Patient details updated successfully!');
      } else {
        alert('Invalid input. Please enter a valid name.');
      }
    } else {
      alert('Patient not found.');
    }
  }

  // Function to edit doctor details by ID
  function editDoctorById(doctorId) {
    var index = doctors.findIndex(function (doctor) {
      return doctor.id === doctorId;
    });

    if (index !== -1) {
      var newName = prompt('Enter the new name for the doctor:');
      if (newName !== null) {
        doctors[index].name = newName;
        updateDoctorList();
        alert('Doctor details updated successfully!');
      } else {
        alert('Invalid input. Please enter a valid name.');
      }
    } else {
      alert('Doctor not found.');
    }
  }

  // Function to edit appointment details by ID
  function editAppointmentById(appointmentId) {
    var index = appointments.findIndex(function (appointment) {
      return appointment.id === appointmentId;
    });

    if (index !== -1) {
      var newPatient = prompt('Enter the new patient name:');
      var newDoctor = prompt('Enter the new doctor name:');
      var newDate = prompt('Enter the new appointment date (YYYY-MM-DD):');

      if (newPatient !== null && newDoctor !== null && isValidDate(newDate)) {
        appointments[index].patient = newPatient;
        appointments[index].doctor = newDoctor;
        appointments[index].date = newDate;
        updateAppointmentList();
        alert('Appointment details updated successfully!');
      } else {
        alert('Invalid input. Please enter valid patient name, doctor name, and date.');
      }
    } else {
      alert('Appointment not found.');
    }
  }

  // Event listener for edit patient button
  document.getElementById('editPatientBtn').addEventListener('click', function () {
    var patientIdToEdit = parseInt(prompt('Enter the ID of the patient to edit:'));
    if (!isNaN(patientIdToEdit)) {
      editPatientById(patientIdToEdit);
    } else {
      alert('Invalid input. Please enter a valid patient ID.');
    }
  });

  // Event listener for edit doctor button
  document.getElementById('editDoctorBtn').addEventListener('click', function () {
    var doctorIdToEdit = parseInt(prompt('Enter the ID of the doctor to edit:'));
    if (!isNaN(doctorIdToEdit)) {
      editDoctorById(doctorIdToEdit);
    } else {
      alert('Invalid input. Please enter a valid doctor ID.');
    }
  });

  // Event listener for edit appointment button
  document.getElementById('editAppointmentBtn').addEventListener('click', function () {
    var appointmentIdToEdit = parseInt(prompt('Enter the ID of the appointment to edit:'));
    if (!isNaN(appointmentIdToEdit)) {
      editAppointmentById(appointmentIdToEdit);
    } else {
      alert('Invalid input. Please enter a valid appointment ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to view a summary of the hospital management system
  function viewSystemSummary() {
    var summary =
      'Hospital Management System Summary:\n\n' +
      'Total Patients: ' +
      patients.length +
      '\nTotal Doctors: ' +
      doctors.length +
      '\nTotal Appointments: ' +
      appointments.length;

    alert(summary);
  }

  // Event listener for view system summary button
  document.getElementById('viewSystemSummaryBtn').addEventListener('click', function () {
    viewSystemSummary();
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to sort patients by name
  function sortPatientsByName() {
    patients.sort(function (a, b) {
      return a.name.localeCompare(b.name);
    });

    updatePatientList();
  }

  // Function to sort doctors by name
  function sortDoctorsByName() {
    doctors.sort(function (a, b) {
      return a.name.localeCompare(b.name);
    });

    updateDoctorList();
  }

  // Function to sort appointments by date
  function sortAppointmentsByDate() {
    appointments.sort(function (a, b) {
      return new Date(a.date) - new Date(b.date);
    });

    updateAppointmentList();
  }

  // Event listener for sort patients button
  document.getElementById('sortPatientsBtn').addEventListener('click', function () {
    sortPatientsByName();
  });

  // Event listener for sort doctors button
  document.getElementById('sortDoctorsBtn').addEventListener('click', function () {
    sortDoctorsByName();
  });

  // Event listener for sort appointments button
  document.getElementById('sortAppointmentsBtn').addEventListener('click', function () {
    sortAppointmentsByDate();
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to track patient medical records
  function trackPatientMedicalRecords(patientId) {
    var index = patients.findIndex(function (patient) {
      return patient.id === patientId;
    });

    if (index !== -1) {
      var medicalRecord = prompt('Enter medical record for patient ' + patients[index].name + ':');
      if (medicalRecord !== null) {
        patients[index].medicalRecord = medicalRecord;
        alert('Medical record for patient ' + patients[index].name + ' updated successfully!');
      } else {
        alert('Invalid input. Please enter a valid medical record.');
      }
    } else {
      alert('Patient not found.');
    }
  }

  // Event listener for track patient medical records button
  document.getElementById('trackMedicalRecordsBtn').addEventListener('click', function () {
    var patientIdToTrack = parseInt(prompt('Enter the ID of the patient to track medical records:'));
    if (!isNaN(patientIdToTrack)) {
      trackPatientMedicalRecords(patientIdToTrack);
    } else {
      alert('Invalid input. Please enter a valid patient ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to schedule recurring appointments for a patient
  function scheduleRecurringAppointments(patientId) {
    var index = patients.findIndex(function (patient) {
      return patient.id === patientId;
    });

    if (index !== -1) {
      var doctorName = prompt('Enter the name of the doctor for recurring appointments:');
      var recurrenceInterval = parseInt(prompt('Enter the recurrence interval in days:'));

      if (doctorName !== null && !isNaN(recurrenceInterval) && recurrenceInterval > 0) {
        var startDate = new Date(prompt('Enter the start date for recurring appointments (YYYY-MM-DD):'));

        if (isValidDate(startDate)) {
          // Schedule recurring appointments for the next few weeks
          for (var i = 0; i < 4; i++) {
            var newDate = new Date(startDate);
            newDate.setDate(newDate.getDate() + i * recurrenceInterval);

            // Add the recurring appointment to the list
            appointments.push({
              id: generateUniqueId(),
              patient: patients[index].name,
              doctor: doctorName,
              date: formatDate(newDate),
            });
          }

          updateAppointmentList();
          alert('Recurring appointments scheduled successfully!');
        } else {
          alert('Invalid start date. Please enter a valid date.');
        }
      } else {
        alert('Invalid input. Please enter a valid doctor name and recurrence interval.');
      }
    } else {
      alert('Patient not found.');
    }
  }

  // Event listener for schedule recurring appointments button
  document.getElementById('scheduleRecurringAppointmentsBtn').addEventListener('click', function () {
    var patientIdToSchedule = parseInt(prompt('Enter the ID of the patient to schedule recurring appointments:'));
    if (!isNaN(patientIdToSchedule)) {
      scheduleRecurringAppointments(patientIdToSchedule);
    } else {
      alert('Invalid input. Please enter a valid patient ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to view upcoming appointments for a specific doctor
  function viewUpcomingAppointmentsForDoctor(doctorName) {
    var upcomingAppointments = appointments.filter(function (appointment) {
      return appointment.doctor.toLowerCase() === doctorName.toLowerCase() && isFutureDate(appointment.date);
    });

    if (upcomingAppointments.length > 0) {
      var appointmentDetails = upcomingAppointments
        .map(function (appointment) {
          return 'Patient: ' + appointment.patient + '\tDate: ' + appointment.date;
        })
        .join('\n');

      alert('Upcoming Appointments for ' + doctorName + ':\n\n' + appointmentDetails);
    } else {
      alert('No upcoming appointments found for ' + doctorName + '.');
    }
  }

  // Event listener for view upcoming appointments for doctor button
  document.getElementById('viewUpcomingAppointmentsForDoctorBtn').addEventListener('click', function () {
    var doctorNameToView = prompt('Enter the name of the doctor to view upcoming appointments:');
    if (doctorNameToView !== null) {
      viewUpcomingAppointmentsForDoctor(doctorNameToView);
    } else {
      alert('Invalid input. Please enter a valid doctor name.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to check the availability of a doctor at a specific date and time
  function checkDoctorAvailability() {
    var doctorName = prompt('Enter the name of the doctor to check availability:');
    var checkDate = new Date(prompt('Enter the date to check availability (YYYY-MM-DD):'));
    var checkTime = prompt('Enter the time to check availability (HH:MM AM/PM):');

    if (isValidDate(checkDate) && isValidTime(checkTime)) {
      var checkDateTime = new Date(checkDate.toDateString() + ' ' + formatTime(checkTime));

      var isAvailable = !appointments.some(function (appointment) {
        return (
          appointment.doctor.toLowerCase() === doctorName.toLowerCase() &&
          new Date(appointment.date + ' ' + appointment.time) >= checkDateTime &&
          new Date(appointment.date + ' ' + appointment.time) < new Date(checkDateTime.getTime() + 60 * 60 * 1000)
        );
      });

      if (isAvailable) {
        alert('The doctor ' + doctorName + ' is available at ' + formatDateTime(checkDateTime) + '.');
      } else {
        alert('The doctor ' + doctorName + ' is not available at ' + formatDateTime(checkDateTime) + '.');
      }
    } else {
      alert('Invalid input. Please enter a valid date and time.');
    }
  }

  // Event listener for check doctor availability button
  document.getElementById('checkDoctorAvailabilityBtn').addEventListener('click', function () {
    checkDoctorAvailability();
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to generate and display reports for patient appointments
  function generateAppointmentReports() {
    var startDate = new Date(prompt('Enter the start date for the report (YYYY-MM-DD):'));
    var endDate = new Date(prompt('Enter the end date for the report (YYYY-MM-DD):'));

    if (isValidDate(startDate) && isValidDate(endDate) && startDate <= endDate) {
      var filteredAppointments = appointments.filter(function (appointment) {
        var appointmentDate = new Date(appointment.date);
        return appointmentDate >= startDate && appointmentDate <= endDate;
      });

      if (filteredAppointments.length > 0) {
        var reportDetails = filteredAppointments
          .map(function (appointment) {
            return (
              'Patient: ' +
              appointment.patient +
              '\tDoctor: ' +
              appointment.doctor +
              '\tDate: ' +
              appointment.date +
              '\tTime: ' +
              appointment.time
            );
          })
          .join('\n');

        alert('Appointment Report for ' + formatDateTime(startDate) + ' to ' + formatDateTime(endDate) + ':\n\n' + reportDetails);
      } else {
        alert('No appointments found within the specified date range.');
      }
    } else {
      alert('Invalid input. Please enter valid start and end dates.');
    }
  }

  // Event listener for generate appointment reports button
  document.getElementById('generateAppointmentReportsBtn').addEventListener('click', function () {
    generateAppointmentReports();
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to cancel or remove an appointment by ID
  function cancelAppointmentById(appointmentId) {
    var index = appointments.findIndex(function (appointment) {
      return appointment.id === appointmentId;
    });

    if (index !== -1) {
      var confirmation = confirm('Are you sure you want to cancel the appointment for ' + appointments[index].patient + '?');
      if (confirmation) {
        appointments.splice(index, 1);
        updateAppointmentList();
        alert('Appointment canceled successfully!');
      } else {
        alert('Appointment cancellation canceled.');
      }
    } else {
      alert('Appointment not found.');
    }
  }

  // Event listener for cancel appointment button
  document.getElementById('cancelAppointmentBtn').addEventListener('click', function () {
    var appointmentIdToCancel = parseInt(prompt('Enter the ID of the appointment to cancel:'));
    if (!isNaN(appointmentIdToCancel)) {
      cancelAppointmentById(appointmentIdToCancel);
    } else {
      alert('Invalid input. Please enter a valid appointment ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to calculate and display statistics about appointments
  function displayAppointmentStatistics() {
    var totalAppointments = appointments.length;
    var totalUniquePatients = new Set(appointments.map((appointment) => appointment.patient)).size;
    var totalUniqueDoctors = new Set(appointments.map((appointment) => appointment.doctor)).size;

    var earliestAppointment = new Date(Math.min(...appointments.map((appointment) => new Date(appointment.date))));
    var latestAppointment = new Date(Math.max(...appointments.map((appointment) => new Date(appointment.date))));

    alert(
      'Appointment Statistics:\n\n' +
        'Total Appointments: ' +
        totalAppointments +
        '\nTotal Unique Patients: ' +
        totalUniquePatients +
        '\nTotal Unique Doctors: ' +
        totalUniqueDoctors +
        '\nEarliest Appointment: ' +
        formatDate(earliestAppointment) +
        '\nLatest Appointment: ' +
        formatDate(latestAppointment)
    );
  }

  // Event listener for display appointment statistics button
  document.getElementById('displayAppointmentStatisticsBtn').addEventListener('click', function () {
    displayAppointmentStatistics();
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to filter and display appointments based on specific criteria
  function filterAndDisplayAppointments() {
    var filterCriteria = prompt(
      'Enter the filter criteria (e.g., patient name, doctor name, date in YYYY-MM-DD format):'
    );

    if (filterCriteria !== null && filterCriteria.trim() !== '') {
      var filteredAppointments = appointments.filter(function (appointment) {
        return (
          appointment.patient.toLowerCase().includes(filterCriteria.toLowerCase()) ||
          appointment.doctor.toLowerCase().includes(filterCriteria.toLowerCase()) ||
          appointment.date.includes(filterCriteria)
        );
      });

      if (filteredAppointments.length > 0) {
        var filteredAppointmentDetails = filteredAppointments
          .map(function (appointment) {
            return (
              'Patient: ' +
              appointment.patient +
              '\tDoctor: ' +
              appointment.doctor +
              '\tDate: ' +
              appointment.date +
              '\tTime: ' +
              appointment.time
            );
          })
          .join('\n');

        alert('Filtered Appointments:\n\n' + filteredAppointmentDetails);
      } else {
        alert('No appointments found matching the specified criteria.');
      }
    } else {
      alert('Invalid input. Please enter a valid filter criteria.');
    }
  }

  // Event listener for filter and display appointments button
  document.getElementById('filterAndDisplayAppointmentsBtn').addEventListener('click', function () {
    filterAndDisplayAppointments();
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to edit and update existing patient records
  function editPatientRecord(patientId) {
    var index = patients.findIndex(function (patient) {
      return patient.id === patientId;
    });

    if (index !== -1) {
      var newName = prompt('Enter the updated name for patient ' + patients[index].name + ':');
      var newAge = parseInt(prompt('Enter the updated age for patient ' + patients[index].name + ':'));
      var newGender = prompt('Enter the updated gender for patient ' + patients[index].name + ':');
      var newContact = prompt('Enter the updated contact number for patient ' + patients[index].name + ':');

      if (newName !== null && !isNaN(newAge) && newAge > 0 && newGender !== null && newContact !== null) {
        patients[index].name = newName;
        patients[index].age = newAge;
        patients[index].gender = newGender;
        patients[index].contact = newContact;

        updatePatientList();
        alert('Patient record for ' + newName + ' updated successfully!');
      } else {
        alert('Invalid input. Please enter valid patient details.');
      }
    } else {
      alert('Patient not found.');
    }
  }

  // Event listener for edit patient record button
  document.getElementById('editPatientRecordBtn').addEventListener('click', function () {
    var patientIdToEdit = parseInt(prompt('Enter the ID of the patient to edit record:'));
    if (!isNaN(patientIdToEdit)) {
      editPatientRecord(patientIdToEdit);
    } else {
      alert('Invalid input. Please enter a valid patient ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});
document.addEventListener('DOMContentLoaded', function () {
  // ... (Previous code remains unchanged)

  // Function to edit and update existing doctor records
  function editDoctorRecord(doctorId) {
    var index = doctors.findIndex(function (doctor) {
      return doctor.id === doctorId;
    });

    if (index !== -1) {
      var newDoctorName = prompt('Enter the updated name for doctor ' + doctors[index].name + ':');
      var newSpecialty = prompt('Enter the updated specialty for doctor ' + doctors[index].name + ':');
      var newContact = prompt('Enter the updated contact number for doctor ' + doctors[index].name + ':');

      if (newDoctorName !== null && newSpecialty !== null && newContact !== null) {
        doctors[index].name = newDoctorName;
        doctors[index].specialty = newSpecialty;
        doctors[index].contact = newContact;

        updateDoctorList();
        alert('Doctor record for ' + newDoctorName + ' updated successfully!');
      } else {
        alert('Invalid input. Please enter valid doctor details.');
      }
    } else {
      alert('Doctor not found.');
    }
  }

  // Event listener for edit doctor record button
  document.getElementById('editDoctorRecordBtn').addEventListener('click', function () {
    var doctorIdToEdit = parseInt(prompt('Enter the ID of the doctor to edit record:'));
    if (!isNaN(doctorIdToEdit)) {
      editDoctorRecord(doctorIdToEdit);
    } else {
      alert('Invalid input. Please enter a valid doctor ID.');
    }
  });

  // Add any additional JavaScript logic as needed for your specific requirements
});